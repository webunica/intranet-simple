<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Intranet_Documents_Functions {
    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function enqueue_scripts() {
        wp_enqueue_style( 'intranet-documents-style', INTRANET_DOCUMENTS_PLUGIN_URL . 'assets/css/style.css' );
        wp_enqueue_script( 'intranet-documents-script', INTRANET_DOCUMENTS_PLUGIN_URL . 'assets/js/script.js', array('jquery'), INTRANET_DOCUMENTS_VERSION, true );
    }
}

new Intranet_Documents_Functions();
