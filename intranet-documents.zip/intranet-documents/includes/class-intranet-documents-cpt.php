<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Intranet_Documents_CPT {
    public function __construct() {
        add_action( 'init', array( $this, 'register_cpt' ) );
    }

    public function register_cpt() {
        $labels = array(
            'name' => 'Documentos Intranet',
            'singular_name' => 'Documento Intranet',
            'menu_name' => 'Documentos Intranet',
            'add_new' => 'Añadir Nuevo',
            'add_new_item' => 'Añadir Nuevo Documento Intranet',
            'edit_item' => 'Editar Documento Intranet',
            'new_item' => 'Nuevo Documento Intranet',
            'view_item' => 'Ver Documento Intranet',
            'search_items' => 'Buscar Documentos Intranet',
            'not_found' => 'No se encontraron documentos.',
            'not_found_in_trash' => 'No se encontraron documentos en la papelera.'
        );

        $args = array(
            'labels' => $labels,
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array( 'slug' => 'intranet_document' ),
            'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => false,
            'menu_position' => 5,
            'supports' => array( 'title', 'editor', 'author' )
        );

        register_post_type( 'intranet_document', $args );
    }
}

new Intranet_Documents_CPT();
