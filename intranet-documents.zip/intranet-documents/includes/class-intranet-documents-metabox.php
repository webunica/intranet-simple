<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Intranet_Documents_Metabox {
    public function __construct() {
        add_action( 'add_meta_boxes', array( $this, 'add_custom_metabox' ) );
        add_action( 'save_post', array( $this, 'save_metaboxes' ) );
    }

    public function add_custom_metabox() {
        add_meta_box(
            'intranet_documents_file_upload',
            'Cargar Documento',
            array( $this, 'render_metabox_content' ),
            'intranet_document',
            'normal',
            'high'
        );
    }

    public function render_metabox_content( $post ) {
        // Añadir un nonce para verificar más adelante cuando guardemos los datos
        wp_nonce_field( basename( __FILE__ ), 'intranet_documents_file_upload_nonce' );

        // Obtener el valor actual del metafield _intranet_document_file
        $document_file = get_post_meta( $post->ID, '_intranet_document_file', true );

        // Obtener el valor actual del metafield _intranet_document_category
        $document_category = get_post_meta( $post->ID, '_intranet_document_category', true );

        // Obtener el valor actual del metafield _intranet_document_user
        $document_user = get_post_meta( $post->ID, '_intranet_document_user', true );

        ?>
        <p>
            <label for="intranet_document_file">Adjuntar Documento:</label><br>
            <input type="text" id="intranet_document_file" name="intranet_document_file" value="<?php echo esc_attr( $document_file ); ?>" size="50">
            <input type="button" id="upload_document_button" class="button" value="Subir/Actualizar Documento">
        </p>

        <p>
            <label for="intranet_document_category">Categoría:</label><br>
            <input type="text" id="intranet_document_category" name="intranet_document_category" value="<?php echo esc_attr( $document_category ); ?>" size="50">
        </p>

        <p>
            <label for="intranet_document_user">Usuario que verá el documento:</label><br>
            <input type="text" id="intranet_document_user" name="intranet_document_user" value="<?php echo esc_attr( $document_user ); ?>" size="50">
        </p>
        <?php
    }

    public function save_metaboxes( $post_id ) {
        // Verificar el nonce
        if ( ! isset( $_POST['intranet_documents_file_upload_nonce'] ) || ! wp_verify_nonce( $_POST['intranet_documents_file_upload_nonce'], basename( __FILE__ ) ) ) {
            return $post_id;
        }

        // Evitar guardar en autosave
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }

        // Verificar permisos de usuario
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return $post_id;
        }

        // Actualizar metafield _intranet_document_file si está presente en $_POST
        if ( isset( $_POST['intranet_document_file'] ) ) {
            update_post_meta( $post_id, '_intranet_document_file', sanitize_text_field( $_POST['intranet_document_file'] ) );
        }

        // Actualizar metafield _intranet_document_category si está presente en $_POST
        if ( isset( $_POST['intranet_document_category'] ) ) {
            update_post_meta( $post_id, '_intranet_document_category', sanitize_text_field( $_POST['intranet_document_category'] ) );
        }

        // Actualizar metafield _intranet_document_user si está presente en $_POST
        if ( isset( $_POST['intranet_document_user'] ) ) {
            update_post_meta( $post_id, '_intranet_document_user', sanitize_text_field( $_POST['intranet_document_user'] ) );
        }
    }
}

new Intranet_Documents_Metabox();
