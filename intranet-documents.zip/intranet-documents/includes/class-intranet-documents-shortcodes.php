<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Intranet_Documents_Shortcodes {
    public function __construct() {
        add_shortcode( 'certificados', array( $this, 'certificados_shortcode' ) );
        add_shortcode( 'documentos_empresa', array( $this, 'documentos_empresa_shortcode' ) );
        add_shortcode( 'documentos_operaciones', array( $this, 'documentos_operaciones_shortcode' ) );
    }

    public function certificados_shortcode( $atts ) {
        return $this->generate_document_list( 'certificados' );
    }

    public function documentos_empresa_shortcode( $atts ) {
        return $this->generate_document_list( 'documentos_empresa' );
    }

    public function documentos_operaciones_shortcode( $atts ) {
        return $this->generate_document_list( 'documentos_operaciones' );
    }

    private function generate_document_list( $category ) {
        $args = array(
            'post_type'      => 'intranet_document',
            'posts_per_page' => -1,
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'     => '_intranet_document_category',
                    'value'   => $category,
                    'compare' => '=',
                ),
                array(
                    'key'     => '_intranet_document_file',
                    'compare' => 'EXISTS',
                ),
            ),
        );

        $documents = new WP_Query( $args );

        if ( $documents->have_posts() ) {
            $output = '<ul>';

            while ( $documents->have_posts() ) {
                $documents->the_post();
                $document_id = get_post_meta( get_the_ID(), '_intranet_document_file', true );
                $document_url = wp_get_attachment_url( $document_id );
                $document_title = get_the_title();

                if ( $document_url && $document_id ) {
                    $document_icon = $this->get_document_icon( $document_url );
                    $output .= '<li><a href="' . esc_url( $document_url ) . '" target="_blank">' . esc_html( $document_title ) . '</a> (' . esc_html( get_the_date() ) . ')' . $document_icon . '</li>';
                } else {
                    $output .= '<li>Error: No se pudo obtener el enlace al archivo adjunto.</li>';
                }
            }

            $output .= '</ul>';

            wp_reset_postdata();

            return $output;
        } else {
            return 'No se encontraron documentos para esta categoría.';
        }
    }

    private function get_document_icon( $document_url ) {
        $icon = '';

        if ( $document_url ) {
            $filetype = wp_check_filetype( $document_url );

            if ( $filetype['ext'] === 'pdf' ) {
                $icon = ' <i class="far fa-file-pdf"></i>';
            } elseif ( strpos( $filetype['type'], 'image/' ) !== false ) {
                $icon = ' <i class="far fa-file-image"></i>';
            }
        }

        return $icon;
    }
}

new Intranet_Documents_Shortcodes();
