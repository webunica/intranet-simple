<?php
/*
Plugin Name: Intranet Documents
Description: Plugin para subir archivos a usuarios específicos de forma privada.
Version: 2.0.1
Author: javier Millar
*/

// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definir constantes
define( 'INTRANET_DOCUMENTS_VERSION', '1.1' );
define( 'INTRANET_DOCUMENTS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'INTRANET_DOCUMENTS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Incluir archivos
include_once INTRANET_DOCUMENTS_PLUGIN_DIR . 'includes/class-intranet-documents-cpt.php';
include_once INTRANET_DOCUMENTS_PLUGIN_DIR . 'includes/class-intranet-documents-metabox.php';
include_once INTRANET_DOCUMENTS_PLUGIN_DIR . 'includes/class-intranet-documents-shortcodes.php';
include_once INTRANET_DOCUMENTS_PLUGIN_DIR . 'includes/class-intranet-documents-functions.php';

// Registrar hooks
register_activation_hook( __FILE__, 'intranet_documents_activate' );
register_deactivation_hook( __FILE__, 'intranet_documents_deactivate' );

// Funciones de activación y desactivación
function intranet_documents_activate() {
    // Código para ejecutar al activar el plugin
    flush_rewrite_rules();
}

function intranet_documents_deactivate() {
    // Código para ejecutar al desactivar el plugin
    flush_rewrite_rules();
}
